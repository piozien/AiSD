namespace AISD_8._11_wezel
{
    public partial class Form1 : Form
    {

        string napis = "";

        public Form1()
        {
            InitializeComponent();
        }
       
        private void StartBT_Click(object sender, EventArgs e)
        {
            var w1 = new w�ze�(5);
            var w2 = new w�ze�(3);
            var w3 = new w�ze�(1);
            var w4 = new w�ze�(2);
            var w5 = new w�ze�(6);
            var w6 = new w�ze�(4);

            w1.dzieci.Add(w2);
            w1.dzieci.Add(w3);
            w1.dzieci.Add(w4);
            w2.dzieci.Add(w5);
            w2.dzieci.Add(w6);
            A(w1);
            MessageBox.Show(napis);

        }
        void A(w�ze� w)
        {   
            //najpierw wypisuje korze� a p�niej schodz� do "dzieci"
            // napis += " " + w.wartosc.ToString();
            for(int i=0; i<w.dzieci.Count; i++)
            {
                A(w.dzieci[i]);
            }
            //zaznaczam najpierw to co odwiedzi�em a p�niej ide w strone korzenia
            napis += " " + w.wartosc.ToString();
        }
    }
    class w�ze�
    {
        public int wartosc;
        public List<w�ze�> dzieci = new List<w�ze�>();
        
        public w�ze�(int wartosc)
        {
            this.wartosc = wartosc;
            
        }
       
    }
    
    
}